"""Barre de HUD : cœurs, éliminations, manches et objectif."""

from __future__ import annotations

import pygame

from . import assets
from . import settings as S


def draw(screen: pygame.Surface, match) -> None:
    pygame.draw.rect(screen, S.HUD_BG, (0, 0, S.WIDTH, S.HUD_H))
    pygame.draw.line(
        screen, S.HUD_LINE, (0, S.HUD_H - 1), (S.WIDTH, S.HUD_H - 1), 2
    )
    _draw_side(screen, match, 0, left=True)
    _draw_side(screen, match, 1, left=False)
    _draw_center(screen, match)


def _draw_side(screen: pygame.Surface, match, index: int, left: bool) -> None:
    player = match.players[index]
    kills = match.kills[index]
    color = player.color
    label = f"J{index + 1}"

    if left:
        x = 16
        pygame.draw.rect(screen, color, (x, 10, 6, 28), border_radius=3)
        assets.draw_text(
            screen, label, 18, (x + 16, S.HUD_H // 2), color,
            anchor="midleft", bold=True
        )
        heart_x = x + 62
        for slot in range(S.MAX_HP):
            assets.draw_heart(
                screen, (heart_x + slot * 22, S.HUD_H // 2), 16,
                slot < player.hp, color
            )
        assets.draw_text(
            screen, f"{kills}/{S.KILLS_TO_WIN_ROUND}", 20,
            (heart_x + S.MAX_HP * 22 + 10, S.HUD_H // 2),
            S.WHITE, anchor="midleft", bold=True
        )
    else:
        x = S.WIDTH - 16
        pygame.draw.rect(screen, color, (x - 6, 10, 6, 28), border_radius=3)
        assets.draw_text(
            screen, label, 18, (x - 16, S.HUD_H // 2), color,
            anchor="midright", bold=True
        )
        heart_x = x - 62
        for slot in range(S.MAX_HP):
            assets.draw_heart(
                screen, (heart_x - slot * 22, S.HUD_H // 2), 16,
                slot < player.hp, color
            )
        assets.draw_text(
            screen, f"{kills}/{S.KILLS_TO_WIN_ROUND}", 20,
            (heart_x - S.MAX_HP * 22 - 10, S.HUD_H // 2),
            S.WHITE, anchor="midright", bold=True
        )


def _draw_center(screen: pygame.Surface, match) -> None:
    center_x = S.WIDTH // 2
    assets.draw_text(
        screen, f"MANCHE {match.round_index}", 13, (center_x, 12),
        S.TEXT_DIM, anchor="center", bold=True
    )
    assets.draw_text(
        screen, f"PREMIER À {S.KILLS_TO_WIN_ROUND}", 17, (center_x, 32),
        S.ACCENT, anchor="center", bold=True
    )

    for index, player in enumerate(match.players):
        for slot in range(S.ROUNDS_TO_WIN_MATCH):
            if index == 0:
                px = center_x - 130 + slot * 16
            else:
                px = center_x + 130 - slot * 16
            won = slot < match.round_wins[index]
            color = player.color if won else (52, 60, 88)
            pygame.draw.circle(screen, color, (px, S.HUD_H // 2), 5)
