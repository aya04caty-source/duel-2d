"""Chargement, rendu et collisions des arènes ASCII.

Légende des niveaux (`levels/*.txt`, 40 colonnes x 21 lignes) :

    #   bloc solide
    =   plateforme traversable par le bas
    1   point d'apparition du joueur 1
    2   point d'apparition du joueur 2
    T   cible du tutoriel
    E   sortie du tutoriel
    .   case vide
"""

from __future__ import annotations

import os

import pygame

from . import assets
from . import settings as S


class Arena:
    def __init__(self, name: str, rows: list[str]) -> None:
        self.name = name
        self.rows = self._normalize(rows)
        self.solid: set[tuple[int, int]] = set()
        self.oneway: set[tuple[int, int]] = set()
        self.spawns: dict[int, pygame.Vector2] = {}
        self.targets: list[pygame.Rect] = []
        self.exit_rect: pygame.Rect | None = None

        for ty, row in enumerate(self.rows):
            for tx, char in enumerate(row):
                if char == "#":
                    self.solid.add((tx, ty))
                elif char == "=":
                    self.oneway.add((tx, ty))
                elif char in "12":
                    self.spawns[int(char) - 1] = self._spawn_point(tx, ty)
                elif char == "T":
                    self.targets.append(self.tile_rect(tx, ty).inflate(-6, -6))
                elif char == "E":
                    self.exit_rect = self.tile_rect(tx, ty).inflate(-4, -4)

        self._ensure_spawns()
        self.surface = self._render()

    # -- construction -------------------------------------------------------
    @staticmethod
    def _normalize(rows: list[str]) -> list[str]:
        cleaned = [row.rstrip("\r\n") for row in rows]
        while cleaned and not cleaned[-1].strip():
            cleaned.pop()
        if len(cleaned) != S.ARENA_H:
            raise ValueError(
                f"arène invalide : {len(cleaned)} lignes au lieu de {S.ARENA_H}"
            )
        for index, row in enumerate(cleaned):
            if len(row) != S.ARENA_W:
                raise ValueError(
                    f"arène invalide, ligne {index + 1} : {len(row)} colonnes "
                    f"au lieu de {S.ARENA_W}"
                )
        return cleaned

    def _spawn_point(self, tx: int, ty: int) -> pygame.Vector2:
        """Centre horizontal de la case, pieds posés sur la case du dessous."""
        x = tx * S.TILE + S.TILE / 2 - S.PLAYER_W / 2
        y = S.HUD_H + (ty + 1) * S.TILE - S.PLAYER_H
        return pygame.Vector2(x, y)

    def _ensure_spawns(self) -> None:
        floor_y = S.HUD_H + (S.ARENA_H - 1) * S.TILE - S.PLAYER_H
        self.spawns.setdefault(0, pygame.Vector2(3 * S.TILE, floor_y))
        self.spawns.setdefault(1, pygame.Vector2(S.WIDTH - 5 * S.TILE, floor_y))

    @classmethod
    def load(cls, path: str, name: str | None = None) -> "Arena":
        with open(path, "r", encoding="utf-8") as handle:
            rows = handle.read().splitlines()
        label = name or os.path.splitext(os.path.basename(path))[0]
        return cls(label, rows)

    # -- géométrie ----------------------------------------------------------
    @staticmethod
    def tile_rect(tx: int, ty: int) -> pygame.Rect:
        return pygame.Rect(tx * S.TILE, S.HUD_H + ty * S.TILE, S.TILE, S.TILE)

    def _tile_bounds(self, rect: pygame.Rect) -> tuple[int, int, int, int]:
        x0 = max(0, rect.left // S.TILE)
        x1 = min(S.ARENA_W - 1, (rect.right - 1) // S.TILE)
        y0 = max(0, (rect.top - S.HUD_H) // S.TILE)
        y1 = min(S.ARENA_H - 1, (rect.bottom - 1 - S.HUD_H) // S.TILE)
        return x0, x1, y0, y1

    def solid_rects_near(self, rect: pygame.Rect) -> list[pygame.Rect]:
        x0, x1, y0, y1 = self._tile_bounds(rect)
        found = []
        for ty in range(y0, y1 + 1):
            for tx in range(x0, x1 + 1):
                if (tx, ty) in self.solid:
                    found.append(self.tile_rect(tx, ty))
        return found

    def oneway_rects_near(self, rect: pygame.Rect) -> list[pygame.Rect]:
        x0, x1, y0, y1 = self._tile_bounds(rect)
        found = []
        for ty in range(y0, y1 + 1):
            for tx in range(x0, x1 + 1):
                if (tx, ty) in self.oneway:
                    found.append(self.tile_rect(tx, ty))
        return found

    def is_solid_point(self, x: float, y: float) -> bool:
        tx = int(x) // S.TILE
        ty = (int(y) - S.HUD_H) // S.TILE
        return (tx, ty) in self.solid

    def collides_solid(self, rect: pygame.Rect) -> bool:
        return any(
            rect.colliderect(tile) for tile in self.solid_rects_near(rect)
        )

    # -- rendu --------------------------------------------------------------
    def _render(self) -> pygame.Surface:
        surface = assets.make_background((S.WIDTH, S.HEIGHT - S.HUD_H))

        for tx, ty in sorted(self.solid):
            rect = pygame.Rect(tx * S.TILE, ty * S.TILE, S.TILE, S.TILE)
            pygame.draw.rect(surface, S.TILE_FILL, rect)

            above = (tx, ty - 1) in self.solid
            below = (tx, ty + 1) in self.solid
            left = (tx - 1, ty) in self.solid
            right = (tx + 1, ty) in self.solid

            if not above:
                pygame.draw.rect(
                    surface, S.TILE_EDGE, (rect.x, rect.y, rect.width, 4)
                )
            if not below:
                pygame.draw.rect(
                    surface, S.TILE_SHADE,
                    (rect.x, rect.bottom - 5, rect.width, 5)
                )
            if not left:
                pygame.draw.rect(
                    surface, S.TILE_EDGE, (rect.x, rect.y, 2, rect.height)
                )
            if not right:
                pygame.draw.rect(
                    surface, S.TILE_SHADE,
                    (rect.right - 2, rect.y, 2, rect.height)
                )

        for tx, ty in sorted(self.oneway):
            rect = pygame.Rect(tx * S.TILE, ty * S.TILE, S.TILE, 10)
            pygame.draw.rect(surface, S.PLANK, rect)
            pygame.draw.line(
                surface, S.PLANK_EDGE, rect.topleft, rect.topright, 3
            )
            pygame.draw.line(
                surface, (70, 54, 38), rect.bottomleft, rect.bottomright, 2
            )

        return surface

    def draw(self, surface: pygame.Surface) -> None:
        surface.blit(self.surface, (0, S.HUD_H))
