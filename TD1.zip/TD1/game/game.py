"""Boucle principale, machine à états et auto-test sans fenêtre."""

from __future__ import annotations

import glob
import os

import pygame

from . import assets
from . import settings as S
from .arena import Arena
from .input import Input
from .match import Match
from .menu import MainMenu, PauseMenu, ResultsMenu
from .tutorial import Tutorial


class Game:
    def __init__(self) -> None:
        pygame.mixer.pre_init(assets.SAMPLE_RATE, -16, 1, 512)
        pygame.init()
        pygame.display.set_caption(S.TITLE)
        self.screen = pygame.display.set_mode((S.WIDTH, S.HEIGHT))
        self.clock = pygame.time.Clock()
        self.input = Input()
        self.sfx = assets.Sfx()

        self.arenas = self._load_arenas()
        self.tutorial_arena = Arena.load(
            S.project_path(S.LEVELS_DIR, "tutorial.txt")
        )
        self.arena_index = 0
        self.current_arena: Arena | None = None

        self.state = "menu"
        self.menu = MainMenu()
        self.pause = PauseMenu()
        self.results: ResultsMenu | None = None
        self.match: Match | None = None
        self.tutorial: Tutorial | None = None
        self.paused_from = "match"

        self.accumulator = 0.0
        self.running = True
        self.fullscreen = False

    # -- chargement ---------------------------------------------------------
    @staticmethod
    def _load_arenas() -> list[Arena]:
        paths = sorted(
            glob.glob(S.project_path(S.LEVELS_DIR, "arena*.txt"))
        )
        if not paths:
            raise RuntimeError(
                "Aucune arène trouvée dans levels/ (arena*.txt)."
            )
        return [Arena.load(path) for path in paths]

    # -- transitions --------------------------------------------------------
    def start_match(self, next_arena: bool = True) -> None:
        """Démarre un match ; `next_arena=False` rejoue la même arène."""
        if next_arena or self.current_arena is None:
            self.current_arena = self.arenas[
                self.arena_index % len(self.arenas)
            ]
            self.arena_index += 1
        self.match = Match(self.current_arena, self.sfx)
        self.accumulator = 0.0
        self.state = "match"

    def start_tutorial(self) -> None:
        self.tutorial = Tutorial(self.tutorial_arena, self.sfx)
        self.accumulator = 0.0
        self.state = "tutorial"

    def toggle_fullscreen(self) -> None:
        self.fullscreen = not self.fullscreen
        flags = pygame.FULLSCREEN | pygame.SCALED if self.fullscreen else 0
        self.screen = pygame.display.set_mode((S.WIDTH, S.HEIGHT), flags)

    # -- boucle -------------------------------------------------------------
    def run(self) -> None:
        while self.running:
            dt = self.clock.tick(S.FPS) / 1000.0
            self._pump_events()
            self._handle_actions()
            self._update(dt)
            self._draw()
            pygame.display.flip()
            self.input.end_frame()

    def quit(self) -> None:
        pygame.quit()

    def _pump_events(self) -> None:
        for event in pygame.event.get():
            self.input.handle_event(event)

    def _handle_actions(self) -> None:
        if self.input.quit_requested:
            self.running = False
        if self.input.fullscreen_pressed:
            self.toggle_fullscreen()
        if self.input.mute_pressed:
            self.sfx.toggle_mute()

        if self.input.pause_pressed:
            if self.state == "match":
                self.paused_from = "match"
                self.state = "pause"
            elif self.state == "pause":
                self.state = self.paused_from
            elif self.state in ("tutorial", "results"):
                self.state = "menu"
                self.menu.refresh()

        if self.input.restart_pressed and self.state in (
            "match",
            "pause",
            "results",
        ):
            self.start_match(next_arena=False)

    # -- mise à jour --------------------------------------------------------
    def _update(self, dt: float) -> None:
        dt = min(dt, 0.1)

        if self.state == "menu":
            action = self.menu.update(dt, self.input)
            if action is not None:
                self._menu_action(action)
        elif self.state == "match":
            self._simulate_match(dt)
        elif self.state == "tutorial":
            self._simulate_tutorial(dt)
        elif self.state == "pause":
            action = self.pause.update(self.input)
            if action is not None:
                self._pause_action(action)
        elif self.state == "results":
            action = self.results.update(self.input)
            if action is not None:
                self._results_action(action)

    def _simulate_match(self, dt: float) -> None:
        self.accumulator += dt
        steps = 0
        while self.accumulator >= S.STEP and steps < 6:
            self.match.update(S.STEP, self.input)
            self.accumulator -= S.STEP
            steps += 1
            if self.match.finished:
                break
        if self.match.finished and self.state == "match":
            self.accumulator = 0.0
            self.results = ResultsMenu(self.match)
            self.state = "results"

    def _simulate_tutorial(self, dt: float) -> None:
        self.accumulator += dt
        steps = 0
        while self.accumulator >= S.STEP and steps < 6:
            result = self.tutorial.update(S.STEP, self.input)
            self.accumulator -= S.STEP
            steps += 1
            if result == "done":
                self.state = "menu"
                self.menu.refresh()
                self.accumulator = 0.0
                return

    def _menu_action(self, action: str) -> None:
        self.sfx.play("click")
        if action == "play":
            self.start_match()
        elif action == "tutorial":
            self.start_tutorial()
        elif action == "quit":
            self.running = False

    def _pause_action(self, action: str) -> None:
        self.sfx.play("click")
        if action == "resume":
            self.state = self.paused_from
        elif action == "restart":
            self.start_match(next_arena=False)
        elif action == "menu":
            self.state = "menu"
            self.menu.refresh()

    def _results_action(self, action: str) -> None:
        self.sfx.play("click")
        if action == "replay":
            self.start_match(next_arena=False)
        elif action == "menu":
            self.state = "menu"
            self.menu.refresh()

    # -- rendu --------------------------------------------------------------
    def _draw(self) -> None:
        if self.state == "menu":
            self.menu.draw(self.screen, self.input)
        elif self.state == "tutorial":
            self.tutorial.draw(self.screen)
        elif self.state in ("match", "pause", "results"):
            self.match.draw(self.screen)
            if self.state == "pause":
                self.pause.draw(self.screen, self.input)
            elif self.state == "results":
                self.results.draw(self.screen, self.input)
        else:  # pragma: no cover - filet de sécurité
            self.screen.fill(S.BG_BOTTOM)


# ---------------------------------------------------------------------------
# Auto-test sans fenêtre
# ---------------------------------------------------------------------------
def selftest() -> int:
    """Déroule un match et le tutoriel sans affichage réel."""
    problems: list[str] = []

    def check(condition: bool, message: str) -> None:
        if not condition:
            problems.append(message)

    game = Game()
    game._draw()

    game.start_match()
    match = game.match
    check(match is not None, "le match n'a pas été créé")

    game.input.held = {pygame.K_d, pygame.K_f, pygame.K_LEFT, pygame.K_RCTRL}
    start_x = match.players[0].x

    for _ in range(int((S.COUNTDOWN_TIME + 0.5) / S.STEP)):
        game._update(S.STEP)
    check(match.state == Match.PLAYING, "le compte à rebours ne se termine pas")

    for _ in range(90):
        game._update(S.STEP)
    check(
        match.players[0].x != start_x,
        "le joueur 1 ne se déplace pas avec ses touches",
    )
    check(
        len(match.bullets) > 0 or match.kills != [0, 0],
        "aucun tir du joueur 1",
    )

    victim = match.players[1]
    victim.invuln = 0.0
    victim.hp = 1
    victim.take_damage(1, pygame.Vector2(1, 0), game.sfx)
    check(not victim.alive, "le joueur touché devrait être éliminé")
    for _ in range(int((S.RESPAWN_TIME + 0.3) / S.STEP)):
        game._update(S.STEP)
    check(victim.alive, "le joueur éliminé ne réapparaît pas")
    check(match.kills[0] >= 1, "l'élimination n'est pas comptée")

    match.kills[0] = S.KILLS_TO_WIN_ROUND
    game._update(S.STEP)
    check(match.state == Match.ROUND_OVER, "la manche ne se termine pas")

    match.round_wins = [S.ROUNDS_TO_WIN_MATCH, 0]
    for _ in range(600):
        game._update(S.STEP)
        if game.state == "results":
            break
    check(game.state == "results", "l'écran de résultats n'apparaît pas")

    game._draw()
    pause_state = game.state
    game.state = "pause"
    game._draw()
    game.state = pause_state

    game.start_tutorial()
    tutorial = game.tutorial
    check(tutorial is not None, "le tutoriel ne démarre pas")
    for step in tutorial.targets:
        step["alive"] = False
    exit_rect = tutorial.arena.exit_rect
    tutorial.player.x = float(exit_rect.centerx)
    tutorial.player.y = float(exit_rect.centery)
    for _ in range(10):
        game._update(S.STEP)
    check(tutorial.completed, "la sortie du tutoriel ne valide pas l'objectif")
    game._draw()

    save_exists = os.path.exists(S.project_path(S.SAVE_FILE))
    check(save_exists, "save.json n'a pas été écrit après le match")

    game.quit()

    if problems:
        print("SELFTEST ÉCHEC")
        for problem in problems:
            print(f"  - {problem}")
        return 1

    print("SELFTEST OK")
    return 0
