"""Rendu procédural et sons générés : aucun fichier d'asset externe.

Toutes les formes (joueurs, balles, cœurs, fond) sont dessinées par du code, et
les effets sonores sont synthétisés au démarrage dans des buffers 16 bits mono.
"""

from __future__ import annotations

import array
import math
from functools import lru_cache

import pygame

from . import settings as S

SAMPLE_RATE = 22050


# ---------------------------------------------------------------------------
# Polices
# ---------------------------------------------------------------------------
@lru_cache(maxsize=32)
def get_font(size: int, bold: bool = False) -> pygame.font.Font:
    """Retourne une police mise en cache (Segoe UI si disponible)."""
    try:
        return pygame.font.SysFont("segoeui", size, bold=bold)
    except Exception:  # pragma: no cover - dépend du système
        return pygame.font.Font(None, size)


def draw_text(
    surface: pygame.Surface,
    text: str,
    size: int,
    pos: tuple[int, int] | tuple[float, float],
    color: tuple[int, int, int] = S.TEXT,
    anchor: str = "topleft",
    bold: bool = False,
    shadow: bool = False,
) -> pygame.Rect:
    """Dessine du texte et retourne son rectangle."""
    font = get_font(size, bold)
    image = font.render(text, True, color)
    rect = image.get_rect(**{anchor: pos})
    if shadow:
        dark = font.render(text, True, (0, 0, 0))
        dark.set_alpha(110)
        surface.blit(dark, rect.move(2, 2))
    surface.blit(image, rect)
    return rect


# ---------------------------------------------------------------------------
# Fond
# ---------------------------------------------------------------------------
def make_background(size: tuple[int, int]) -> pygame.Surface:
    """Dégradé vertical avec une grille discrète, calculé une seule fois."""
    width, height = size
    surface = pygame.Surface(size).convert()
    for y in range(height):
        ratio = y / max(1, height - 1)
        color = (
            int(S.BG_TOP[0] + (S.BG_BOTTOM[0] - S.BG_TOP[0]) * ratio),
            int(S.BG_TOP[1] + (S.BG_BOTTOM[1] - S.BG_TOP[1]) * ratio),
            int(S.BG_TOP[2] + (S.BG_BOTTOM[2] - S.BG_TOP[2]) * ratio),
        )
        pygame.draw.line(surface, color, (0, y), (width, y))

    grid = pygame.Surface(size, pygame.SRCALPHA)
    for x in range(0, width, 64):
        pygame.draw.line(grid, (255, 255, 255, 6), (x, 0), (x, height))
    for y in range(0, height, 64):
        pygame.draw.line(grid, (255, 255, 255, 6), (0, y), (width, y))
    surface.blit(grid, (0, 0))
    return surface


# ---------------------------------------------------------------------------
# Formes
# ---------------------------------------------------------------------------
def draw_heart(
    surface: pygame.Surface,
    center: tuple[int, int],
    size: int,
    filled: bool,
    color: tuple[int, int, int] = S.DANGER,
) -> None:
    """Dessine un cœur plein ou vide (contour seul)."""
    x, y = center
    radius = max(2, size // 4)
    left = (x - radius, y - radius // 2)
    right = (x + radius, y - radius // 2)
    if filled:
        pygame.draw.circle(surface, color, left, radius)
        pygame.draw.circle(surface, color, right, radius)
        pygame.draw.polygon(
            surface,
            color,
            [
                (x - size // 2, y - radius // 2),
                (x + size // 2, y - radius // 2),
                (x, y + size // 2),
            ],
        )
    else:
        edge = (70, 80, 108)
        pygame.draw.circle(surface, edge, left, radius, 2)
        pygame.draw.circle(surface, edge, right, radius, 2)
        pygame.draw.polygon(
            surface,
            edge,
            [
                (x - size // 2, y - radius // 2),
                (x + size // 2, y - radius // 2),
                (x, y + size // 2),
            ],
            2,
        )


def draw_bullet(
    surface: pygame.Surface,
    pos: pygame.Vector2,
    color: tuple[int, int, int],
    radius: int,
) -> None:
    """Balle lumineuse avec une petite traînée."""
    x, y = int(pos.x), int(pos.y)
    glow = pygame.Surface((radius * 6, radius * 6), pygame.SRCALPHA)
    pygame.draw.circle(glow, (*color, 50), (radius * 3, radius * 3), radius * 3)
    pygame.draw.circle(glow, (*color, 90), (radius * 3, radius * 3), radius * 2)
    surface.blit(glow, (x - radius * 3, y - radius * 3))
    pygame.draw.circle(surface, color, (x, y), radius)
    pygame.draw.circle(surface, S.WHITE, (x, y), max(1, radius // 2))


def draw_player(surface: pygame.Surface, player) -> None:
    """Corps arrondi, viseur orienté et pips de vie au-dessus de la tête."""
    rect = player.rect
    blinking = player.invuln > 0 and int(player.invuln * 18) % 2 == 0

    target = surface
    temp = None
    if blinking:
        temp = pygame.Surface(rect.size, pygame.SRCALPHA)
        target = temp
        offset = (0, 0)
    else:
        offset = (rect.x, rect.y)

    body = pygame.Rect(offset[0], offset[1], rect.width, rect.height)
    pygame.draw.rect(target, player.color, body, border_radius=6)
    inner = body.inflate(-8, -10)
    pygame.draw.rect(target, player.dark_color, inner, border_radius=4)

    # Viseur : œil/barillet orienté vers la direction de tir.
    center = pygame.Vector2(offset[0] + rect.width / 2, offset[1] + rect.height / 2)
    tip = center + player.aim * (rect.width * 0.75)
    pygame.draw.line(target, S.WHITE, center, tip, 3)
    pygame.draw.circle(target, S.WHITE, (int(tip.x), int(tip.y)), 3)

    if temp is not None:
        temp.set_alpha(90)
        surface.blit(temp, rect.topleft)

    # Pips de vie au-dessus de la tête.
    for i in range(S.MAX_HP):
        px = rect.centerx - (S.MAX_HP - 1) * 6 + i * 12
        color = player.color if i < player.hp else (58, 66, 92)
        pygame.draw.circle(surface, color, (px, rect.top - 9), 3)


# ---------------------------------------------------------------------------
# Sons synthétisés
# ---------------------------------------------------------------------------
def _tone(
    freq_start: float,
    freq_end: float,
    duration: float,
    volume: float = 0.32,
    wave: str = "square",
) -> pygame.mixer.Sound:
    """Synthétise un son court (glissando + enveloppe) au format du mixer."""
    info = pygame.mixer.get_init()
    rate = info[0] if info else SAMPLE_RATE
    channels = info[2] if info else 1

    count = max(1, int(rate * duration))
    data = array.array("h")
    phase = 0.0
    for i in range(count):
        progress = i / count
        freq = freq_start + (freq_end - freq_start) * progress
        phase += 2.0 * math.pi * freq / rate
        sine = math.sin(phase)
        if wave == "square":
            value = 1.0 if sine >= 0 else -1.0
        elif wave == "saw":
            value = 2.0 * ((phase / (2.0 * math.pi)) % 1.0) - 1.0
        else:
            value = sine
        attack = min(1.0, i / (rate * 0.004))
        release = 1.0 - progress
        sample = int(value * attack * release * volume * 32767)
        for _ in range(channels):
            data.append(sample)
    return pygame.mixer.Sound(buffer=data.tobytes())


class Sfx:
    """Petit lecteur d'effets sonores, silencieux si l'audio est indisponible."""

    NAMES = (
        "shoot",
        "jump",
        "hit",
        "death",
        "click",
        "round",
        "victory",
        "target",
    )

    def __init__(self, enabled: bool = True) -> None:
        self.enabled = False
        self.muted = False
        self.sounds: dict[str, pygame.mixer.Sound] = {}
        if not enabled:
            return
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(
                    frequency=SAMPLE_RATE, size=-16, channels=1, buffer=512
                )
            pygame.mixer.set_num_channels(16)
            self._build()
            self.enabled = True
        except pygame.error:
            # Pas de périphérique audio : le jeu reste jouable sans son.
            self.enabled = False

    def _build(self) -> None:
        self.sounds = {
            "shoot": _tone(920, 480, 0.07, 0.20, "square"),
            "jump": _tone(360, 720, 0.11, 0.22, "sine"),
            "hit": _tone(300, 140, 0.10, 0.30, "saw"),
            "death": _tone(340, 70, 0.35, 0.30, "square"),
            "click": _tone(1250, 900, 0.04, 0.16, "square"),
            "round": _tone(520, 1180, 0.28, 0.24, "sine"),
            "victory": _tone(660, 1500, 0.45, 0.26, "sine"),
            "target": _tone(880, 1500, 0.08, 0.22, "sine"),
        }

    def toggle_mute(self) -> bool:
        self.muted = not self.muted
        if self.enabled:
            for sound in self.sounds.values():
                sound.set_volume(0.0 if self.muted else 1.0)
        return self.muted

    def play(self, name: str) -> None:
        if not self.enabled or self.muted:
            return
        sound = self.sounds.get(name)
        if sound is not None:
            sound.play()
