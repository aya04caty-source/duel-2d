"""Tutoriel solo court : déplacement, saut, tir et sortie.

Le joueur y utilise exactement les touches du joueur 1 pour que les acquis
soient directement réutilisables en versus.
"""

from __future__ import annotations

import pygame

from . import assets
from . import settings as S
from .entities import Player, burst


class Tutorial:
    MOVE_GOAL = 160.0

    def __init__(self, arena, sfx) -> None:
        self.arena = arena
        self.sfx = sfx
        self.world = pygame.Surface((S.WIDTH, S.HEIGHT)).convert()
        self.background = assets.make_background((S.WIDTH, S.HEIGHT))

        self.player = Player(
            0,
            arena.spawns[0],
            S.P1_KEYS,
            S.P1_COLOR,
            S.P1_DARK,
            S.PLAYER_NAMES[0],
        )
        self.bullets: list = []
        self.particles: list = []
        self.targets = [{"rect": rect, "alive": True} for rect in arena.targets]

        self.steps = [
            {"key": "move", "label": "Se déplacer (ZQSD / WASD)", "done": False},
            {"key": "jump", "label": "Sauter (Espace)", "done": False},
            {"key": "shoot", "label": "Détruire les 3 cibles (F)", "done": False},
            {"key": "exit", "label": "Atteindre la sortie", "done": False},
        ]
        self.moved = 0.0
        self.start_y = self.player.y
        self.lowest_y = self.player.y
        self.completed = False
        self.finished = False
        self.complete_timer = 0.0

    # -- état ---------------------------------------------------------------
    @property
    def targets_left(self) -> int:
        return sum(1 for target in self.targets if target["alive"])

    @property
    def exit_unlocked(self) -> bool:
        return self.targets_left == 0

    def _mark(self, key: str) -> None:
        for step in self.steps:
            if step["key"] == key and not step["done"]:
                step["done"] = True

    # -- mise à jour --------------------------------------------------------
    def update(self, dt: float, inputs) -> str | None:
        if self.completed:
            self.complete_timer -= dt
            self._update_particles(dt)
            return "done" if self.complete_timer <= 0 else None

        previous_x = self.player.x
        self.player.update(dt, self.arena, inputs, self.bullets, self.sfx)
        self.moved += abs(self.player.x - previous_x)
        self.lowest_y = min(self.lowest_y, self.player.y)

        if self.moved >= self.MOVE_GOAL:
            self._mark("move")
        if self.lowest_y <= self.start_y - 48:
            self._mark("jump")

        self._update_bullets(dt)
        self._update_particles(dt)

        if self.targets_left == 0:
            self._mark("shoot")
            if self.arena.exit_rect is not None:
                if self.player.rect.colliderect(self.arena.exit_rect):
                    self._mark("exit")
                    self._complete()

        return None

    def _update_bullets(self, dt: float) -> None:
        for bullet in self.bullets:
            if not bullet.alive:
                continue
            bullet.update(dt, self.arena)
            if not bullet.alive:
                burst(self.particles, bullet.pos, bullet.color, 3, 70, 0.2, 2)
                continue
            for target in self.targets:
                if not target["alive"]:
                    continue
                if bullet.rect.colliderect(target["rect"]):
                    target["alive"] = False
                    bullet.alive = False
                    burst(
                        self.particles,
                        pygame.Vector2(target["rect"].center),
                        S.TARGET_COLOR,
                        16,
                        220,
                        0.5,
                        3,
                    )
                    self.sfx.play("target")
                    break
        self.bullets = [bullet for bullet in self.bullets if bullet.alive]

    def _update_particles(self, dt: float) -> None:
        for particle in self.particles:
            particle.update(dt)
        self.particles = [p for p in self.particles if p.alive]

    def _complete(self) -> None:
        self.completed = True
        self.complete_timer = S.TUTORIAL_COMPLETE_TIME
        self.sfx.play("victory")

    # -- rendu --------------------------------------------------------------
    def draw(self, screen: pygame.Surface) -> None:
        world = self.world
        world.blit(self.background, (0, 0))
        self.arena.draw(world)

        self._draw_exit(world)
        for target in self.targets:
            if target["alive"]:
                self._draw_target(world, target["rect"])
        for particle in self.particles:
            particle.draw(world)
        self.player.draw(world)
        for bullet in self.bullets:
            bullet.draw(world)

        screen.blit(world, (0, 0))
        self._draw_hud(screen)
        if self.completed:
            self._draw_complete(screen)

    def _draw_target(self, surface: pygame.Surface, rect: pygame.Rect) -> None:
        pygame.draw.rect(surface, S.TARGET_COLOR, rect, border_radius=6)
        inner = rect.inflate(-10, -10)
        pygame.draw.rect(surface, (60, 30, 80), inner, border_radius=4)
        pygame.draw.circle(surface, S.TARGET_COLOR, rect.center, 4)

    def _draw_exit(self, surface: pygame.Surface) -> None:
        rect = self.arena.exit_rect
        if rect is None:
            return
        unlocked = self.exit_unlocked
        color = S.EXIT_COLOR if unlocked else (74, 84, 112)
        glow = pygame.Surface((rect.width + 40, rect.height + 40), pygame.SRCALPHA)
        pygame.draw.rect(
            glow, (*color, 70 if unlocked else 30), glow.get_rect(), border_radius=14
        )
        surface.blit(glow, (rect.x - 20, rect.y - 20))
        pygame.draw.rect(surface, color, rect, border_radius=8)
        pygame.draw.rect(surface, S.WHITE if unlocked else (46, 54, 80), rect, 2, 8)
        assets.draw_text(
            surface, "SORTIE", 12, rect.center, (12, 16, 26) if unlocked else (150, 158, 186),
            anchor="center", bold=True
        )

    def _draw_hud(self, screen: pygame.Surface) -> None:
        pygame.draw.rect(screen, S.HUD_BG, (0, 0, S.WIDTH, S.HUD_H))
        pygame.draw.line(
            screen, S.HUD_LINE, (0, S.HUD_H - 1), (S.WIDTH, S.HUD_H - 1), 2
        )
        assets.draw_text(
            screen, "TUTORIEL", 18, (16, S.HUD_H // 2), S.ACCENT,
            anchor="midleft", bold=True
        )
        assets.draw_text(
            screen, "Échap : menu", 15, (S.WIDTH - 16, S.HUD_H // 2),
            S.TEXT_DIM, anchor="midright"
        )

        panel = pygame.Rect(24, S.HUD_H + 18, 330, 34 + 30 * len(self.steps))
        layer = pygame.Surface(panel.size, pygame.SRCALPHA)
        layer.fill((13, 16, 28, 190))
        screen.blit(layer, panel.topleft)
        pygame.draw.rect(screen, S.PANEL_EDGE, panel, width=2, border_radius=10)

        assets.draw_text(
            screen, "OBJECTIFS", 14, (panel.x + 16, panel.y + 12),
            S.TEXT_DIM, bold=True
        )
        for index, step in enumerate(self.steps):
            y = panel.y + 38 + index * 30
            color = S.OK if step["done"] else S.TEXT
            marker = "✓" if step["done"] else "○"
            assets.draw_text(
                screen, f"{marker}  {step['label']}", 16, (panel.x + 16, y),
                color, anchor="topleft"
            )

        if not self.exit_unlocked and self.targets_left > 0:
            assets.draw_text(
                screen,
                f"Cibles restantes : {self.targets_left}",
                16,
                (S.WIDTH // 2, S.HUD_H + 30),
                S.TARGET_COLOR,
                anchor="center",
                bold=True,
            )

    def _draw_complete(self, screen: pygame.Surface) -> None:
        width, height = 620, 170
        panel = pygame.Rect(0, 0, width, height)
        panel.center = (S.WIDTH // 2, S.HEIGHT // 2)
        layer = pygame.Surface(panel.size, pygame.SRCALPHA)
        layer.fill((10, 14, 24, 225))
        screen.blit(layer, panel.topleft)
        pygame.draw.rect(screen, S.OK, panel, width=3, border_radius=16)
        assets.draw_text(
            screen, "TUTORIEL TERMINÉ", 44, (panel.centerx, panel.centery - 24),
            S.OK, anchor="center", bold=True, shadow=True
        )
        assets.draw_text(
            screen, "Retour au menu…", 20, (panel.centerx, panel.centery + 38),
            S.TEXT_DIM, anchor="center"
        )
