﻿"""Constantes globales : Ã©cran, physique, Ã©quilibrage, touches, couleurs.

Tout nombre qui influence le gameplay doit vivre ici, jamais en dur dans la
logique du jeu.
"""

from __future__ import annotations

import os

import pygame

# ---------------------------------------------------------------------------
# Ã‰cran et boucle
# ---------------------------------------------------------------------------
WIDTH, HEIGHT = 1280, 720
FPS = 60
STEP = 1.0 / FPS
TILE = 32
HUD_H = 48

ARENA_W = WIDTH // TILE                 # 40 tuiles
ARENA_H = (HEIGHT - HUD_H) // TILE      # 21 tuiles

TITLE = "Duel 2D"

# ---------------------------------------------------------------------------
# Physique du joueur
# ---------------------------------------------------------------------------
GRAVITY = 2000.0
MAX_FALL = 1100.0
MOVE_ACCEL = 2800.0
MOVE_SPEED = 265.0
GROUND_FRICTION = 2600.0
AIR_FRICTION = 520.0
JUMP_SPEED = 690.0
JUMP_CUT = 0.42
COYOTE_TIME = 0.09
JUMP_BUFFER = 0.12

PLAYER_W = 26
PLAYER_H = 36

# ---------------------------------------------------------------------------
# Combat
# ---------------------------------------------------------------------------
MAX_HP = 3
INVULN_TIME = 1.5
RESPAWN_TIME = 2.0

SHOOT_COOLDOWN = 0.35
BULLET_SPEED = 780.0
BULLET_RADIUS = 5
BULLET_LIFE = 1.5
HIT_KNOCKBACK = 240.0

SHAKE_ON_HIT = 6.0
SHAKE_ON_DEATH = 13.0
SHAKE_ON_ROUND = 7.0
SHAKE_DECAY = 34.0

HIT_LIFT = 140.0
HIT_PUSH = 0.4
FALL_DEATH_MARGIN = 80
SHOOT_MUZZLE = 0.7
ONEWAY_TOLERANCE = 2

TUTORIAL_COMPLETE_TIME = 2.6

# ---------------------------------------------------------------------------
# Match
# ---------------------------------------------------------------------------
KILLS_TO_WIN_ROUND = 3
ROUNDS_TO_WIN_MATCH = 2
MAX_ROUNDS = 5
COUNTDOWN_TIME = 3.0
ROUND_OVER_TIME = 2.6

# ---------------------------------------------------------------------------
# Couleurs
# ---------------------------------------------------------------------------
BG_TOP = (19, 23, 40)
BG_BOTTOM = (8, 10, 18)

TILE_FILL = (42, 50, 76)
TILE_EDGE = (72, 86, 126)
TILE_SHADE = (30, 36, 56)

PLANK = (124, 98, 68)
PLANK_EDGE = (176, 142, 100)

P1_COLOR = (86, 196, 255)
P1_DARK = (40, 104, 150)
P2_COLOR = (255, 108, 128)
P2_DARK = (150, 50, 68)

PLAYER_NAMES = ("Joueur 1", "Joueur 2")

WHITE = (238, 242, 255)
TEXT = (214, 222, 245)
TEXT_DIM = (132, 144, 176)
ACCENT = (255, 208, 92)
DANGER = (255, 96, 96)
OK = (120, 226, 160)

HUD_BG = (13, 16, 28)
HUD_LINE = (46, 56, 88)
PANEL_BG = (22, 27, 45)
PANEL_EDGE = (58, 70, 108)

BTN_BG = (34, 42, 68)
BTN_HOVER = (52, 66, 104)
BTN_EDGE = (78, 94, 140)

TARGET_COLOR = (196, 128, 255)
EXIT_COLOR = (120, 226, 160)

# ---------------------------------------------------------------------------
# Touches (AZERTY ; Q/A et Z/W sont acceptÃ©s pour rester jouable en QWERTY)
# ---------------------------------------------------------------------------
P1_KEYS: dict[str, tuple[int, ...]] = {
    "left": (pygame.K_a, pygame.K_q),
    "right": (pygame.K_d,),
    "up": (pygame.K_w, pygame.K_z),
    "down": (pygame.K_s,),
    "jump": (pygame.K_SPACE,),
    "shoot": (pygame.K_f,),
}

P2_KEYS: dict[str, tuple[int, ...]] = {
    "left": (pygame.K_LEFT,),
    "right": (pygame.K_RIGHT,),
    "up": (pygame.K_UP,),
    "down": (pygame.K_DOWN,),
    "jump": (pygame.K_RSHIFT,),
    "shoot": (pygame.K_RCTRL,),
}

# ---------------------------------------------------------------------------
# Fichiers
# ---------------------------------------------------------------------------
SAVE_FILE = "save.json"
LEVELS_DIR = "levels"

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def project_path(*parts: str) -> str:
    """Chemin absolu depuis la racine du projet, indÃ©pendant du cwd."""
    return os.path.join(PROJECT_ROOT, *parts)

