﻿"""RÃ¨gles du deathmatch : PV, respawn, Ã©liminations, manches et chrono."""

from __future__ import annotations

import json
import math
import os
import random

import pygame

from . import assets
from . import hud
from . import settings as S
from .entities import Bullet, Player, burst


class Match:
    COUNTDOWN = "countdown"
    PLAYING = "playing"
    ROUND_OVER = "round_over"
    MATCH_OVER = "match_over"

    def __init__(self, arena, sfx, save_path: str | None = None) -> None:
        self.arena = arena
        self.sfx = sfx
        self.save_path = save_path or os.path.join(S.PROJECT_ROOT, S.SAVE_FILE)

        self.players = [
            Player(
                0,
                arena.spawns[0],
                S.P1_KEYS,
                S.P1_COLOR,
                S.P1_DARK,
                S.PLAYER_NAMES[0],
            ),
            Player(
                1,
                arena.spawns[1],
                S.P2_KEYS,
                S.P2_COLOR,
                S.P2_DARK,
                S.PLAYER_NAMES[1],
            ),
        ]
        self.bullets: list[Bullet] = []
        self.particles: list = []
        self.kills = [0, 0]
        self.round_wins = [0, 0]
        self.round_index = 1
        self.state = self.COUNTDOWN
        self.timer = S.COUNTDOWN_TIME
        self.round_winner: int | None = None
        self.match_winner: int | None = None
        self.shake = 0.0
        self.finished = False
        self.surface = pygame.Surface((S.WIDTH, S.HEIGHT)).convert()

    # -- boucle -------------------------------------------------------------
    def update(self, dt: float, inputs) -> None:
        self._update_particles(dt)
        self.shake = max(0.0, self.shake - S.SHAKE_DECAY * dt)

        if self.state == self.MATCH_OVER:
            return

        if self.state == self.COUNTDOWN:
            self.timer -= dt
            if self.timer <= 0.0:
                self.state = self.PLAYING
                # La protection d'apparition dÃ©marre Ã  la fin du dÃ©compte,
                # de faÃ§on identique Ã  chaque manche.
                for player in self.players:
                    player.invuln = S.INVULN_TIME
            return

        if self.state == self.ROUND_OVER:
            self.timer -= dt
            if self.timer <= 0.0:
                self._next_phase()
            return

        for player in self.players:
            player.update(dt, self.arena, inputs, self.bullets, self.sfx)

        self._update_bullets(dt)
        self._update_deaths()

        if self.state != self.PLAYING:
            return

        # Une manche se gagne en atteignant l'objectif avec une avance stricte :
        # en cas de double Ã©limination (3-3), la suivante tranche.
        for index in (0, 1):
            opponent = 1 - index
            if (
                self.kills[index] >= S.KILLS_TO_WIN_ROUND
                and self.kills[index] > self.kills[opponent]
            ):
                self._end_round(index)
                return

    def _update_particles(self, dt: float) -> None:
        for particle in self.particles:
            particle.update(dt)
        self.particles = [p for p in self.particles if p.alive]

    def _update_bullets(self, dt: float) -> None:
        for bullet in self.bullets:
            if not bullet.alive:
                continue
            bullet.update(dt, self.arena)
            if not bullet.alive:
                burst(self.particles, bullet.pos, bullet.color, 4, 90, 0.25, 2)
                continue

            for player in self.players:
                if not player.alive or player.index == bullet.owner:
                    continue
                if player.invuln > 0.0:
                    continue
                if bullet.rect.colliderect(player.rect):
                    bullet.alive = False
                    died = player.take_damage(1, bullet.vel, self.sfx)
                    burst(self.particles, bullet.pos, bullet.color, 8, 160, 0.35, 3)
                    self.shake = max(self.shake, S.SHAKE_ON_HIT)
                    if died:
                        self.shake = max(self.shake, S.SHAKE_ON_DEATH)
                    break

        self.bullets = [bullet for bullet in self.bullets if bullet.alive]

    def _update_deaths(self) -> None:
        for player in self.players:
            if not player.died:
                continue
            player.died = False
            opponent = 1 - player.index
            self.kills[opponent] += 1
            burst(self.particles, player.center, player.color, 28, 280, 0.75, 4)
            self.shake = max(self.shake, S.SHAKE_ON_DEATH)
            self.sfx.play("death")

    # -- manches ------------------------------------------------------------
    def _end_round(self, winner: int | None) -> None:
        self.state = self.ROUND_OVER
        self.timer = S.ROUND_OVER_TIME
        self.round_winner = winner
        if winner is not None:
            self.round_wins[winner] += 1
        self.bullets.clear()
        self.shake = max(self.shake, S.SHAKE_ON_ROUND)
        self.sfx.play("round")

    def _next_phase(self) -> None:
        if max(self.round_wins) >= S.ROUNDS_TO_WIN_MATCH:
            if self.round_wins[0] > self.round_wins[1]:
                self._finish_match(0)
            elif self.round_wins[1] > self.round_wins[0]:
                self._finish_match(1)
            else:
                self._finish_match(None)
        elif self.round_index >= S.MAX_ROUNDS:
            # Garde-fou : le match ne peut pas s'Ã©terniser.
            self._finish_match(None)
        else:
            self._start_round()

    def _finish_match(self, winner: int | None) -> None:
        self.state = self.MATCH_OVER
        self.match_winner = winner
        self.finished = True
        self.sfx.play("victory")
        self._save_stats()

    def _start_round(self) -> None:
        self.round_index += 1
        self.kills = [0, 0]
        self.bullets.clear()
        self.particles.clear()
        self.round_winner = None
        for player in self.players:
            player.reset()
            # Protection accordÃ©e Ã  la fin du dÃ©compte, pas pendant.
            player.invuln = 0.0
        self.state = self.COUNTDOWN
        self.timer = S.COUNTDOWN_TIME

    # -- statistiques -------------------------------------------------------
    def _save_stats(self) -> None:
        data = {"p1_wins": 0, "p2_wins": 0, "matches": 0}
        try:
            with open(self.save_path, "r", encoding="utf-8") as handle:
                loaded = json.load(handle)
            if isinstance(loaded, dict):
                for key in data:
                    if isinstance(loaded.get(key), int):
                        data[key] = loaded[key]
        except (OSError, ValueError):
            pass

        data["matches"] += 1
        if self.match_winner == 0:
            data["p1_wins"] += 1
        elif self.match_winner == 1:
            data["p2_wins"] += 1

        try:
            with open(self.save_path, "w", encoding="utf-8") as handle:
                json.dump(data, handle, indent=2)
        except OSError:
            # L'Ã©criture peut Ã©chouer sur une session en lecture seule : sans gravitÃ©.
            pass

    # -- rendu --------------------------------------------------------------
    def draw(self, screen: pygame.Surface) -> None:
        world = self.surface
        world.fill(S.BG_BOTTOM)

        offset = (0, 0)
        if self.shake > 0.5:
            offset = (
                int(random.uniform(-self.shake, self.shake)),
                int(random.uniform(-self.shake, self.shake)),
            )

        self.arena.draw(world)
        for particle in self.particles:
            particle.draw(world)

        for player in self.players:
            if player.alive:
                player.draw(world)
            else:
                self._draw_respawn_marker(world, player)

        for bullet in self.bullets:
            bullet.draw(world)

        screen.blit(world, offset)
        hud.draw(screen, self)
        self._draw_banners(screen)

    def _draw_respawn_marker(self, surface: pygame.Surface, player: Player) -> None:
        position = pygame.Vector2(player.spawn)
        position.x += S.PLAYER_W / 2
        position.y += S.PLAYER_H / 2
        pulse = 18 + int(4 * abs((player.respawn_timer * 3) % 2 - 1))
        pygame.draw.circle(
            surface, player.dark_color, (int(position.x), int(position.y)), pulse, 2
        )
        if player.respawn_timer > 0.1:
            assets.draw_text(
                surface,
                str(max(1, math.ceil(player.respawn_timer))),
                20,
                (int(position.x), int(position.y)),
                player.color,
                anchor="center",
                bold=True,
                shadow=True,
            )

    def _draw_banners(self, screen: pygame.Surface) -> None:
        if self.state == self.COUNTDOWN:
            number = str(max(1, math.ceil(self.timer)))
            assets.draw_text(
                screen,
                number,
                140,
                (S.WIDTH // 2, S.HEIGHT // 2 - 20),
                S.WHITE,
                anchor="center",
                bold=True,
                shadow=True,
            )
            assets.draw_text(
                screen,
                "PRÊTS ?",
                30,
                (S.WIDTH // 2, S.HEIGHT // 2 + 80),
                S.TEXT_DIM,
                anchor="center",
                bold=True,
            )
        elif self.state == self.ROUND_OVER:
            panel = pygame.Rect(0, 0, 800, 220)
            panel.center = (S.WIDTH // 2, S.HEIGHT // 2)
            layer = pygame.Surface(panel.size, pygame.SRCALPHA)
            layer.fill((9, 12, 20, 210))
            screen.blit(layer, panel.topleft)
            pygame.draw.rect(screen, S.PANEL_EDGE, panel, 2, 14)

            if self.round_winner is None:
                title = "MANCHE NULLE"
                color = S.TEXT
            else:
                title = f"{S.PLAYER_NAMES[self.round_winner].upper()} GAGNE"
                color = self.players[self.round_winner].color
            assets.draw_text(
                screen,
                title,
                56,
                (panel.centerx, panel.centery - 34),
                color,
                anchor="center",
                bold=True,
                shadow=True,
            )
            assets.draw_text(
                screen,
                f"{self.kills[0]} â€” {self.kills[1]}",
                38,
                (panel.centerx, panel.centery + 38),
                S.TEXT,
                anchor="center",
                bold=True,
            )

