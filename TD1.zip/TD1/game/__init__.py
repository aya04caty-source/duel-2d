"""Duel 2D — jeu de plateforme/tir compétitif à 2 joueurs en local."""

__version__ = "0.1.0"
