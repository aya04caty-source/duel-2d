"""État clavier / souris partagé par la boucle de jeu.

Les deux joueurs lisent le même objet `Input` mais avec des keymaps distinctes
(voir `settings.P1_KEYS` et `settings.P2_KEYS`). La souris ne sert qu'aux menus.
"""

from __future__ import annotations

import pygame


class Input:
    def __init__(self) -> None:
        self.held: set[int] = set()
        self.pressed: set[int] = set()
        self.released: set[int] = set()

        self.mouse_pos: tuple[int, int] = (0, 0)
        self.mouse_pressed = False
        self.mouse_released = False

        # Actions globales, consommées puis remises à zéro chaque frame.
        self.quit_requested = False
        self.pause_pressed = False
        self.restart_pressed = False
        self.fullscreen_pressed = False
        self.mute_pressed = False

    # -- événements ---------------------------------------------------------
    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.QUIT:
            self.quit_requested = True
        elif event.type == pygame.KEYDOWN:
            self.held.add(event.key)
            self.pressed.add(event.key)
            if event.key == pygame.K_ESCAPE:
                self.pause_pressed = True
            elif event.key == pygame.K_F11:
                self.fullscreen_pressed = True
            elif event.key == pygame.K_m:
                self.mute_pressed = True
            elif event.key == pygame.K_r:
                self.restart_pressed = True
        elif event.type == pygame.KEYUP:
            self.held.discard(event.key)
            self.released.add(event.key)
        elif event.type == pygame.MOUSEMOTION:
            self.mouse_pos = event.pos
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.mouse_pressed = True
            self.mouse_pos = event.pos
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.mouse_released = True
            self.mouse_pos = event.pos
        elif event.type == pygame.WINDOWFOCUSLOST:
            # Alt-Tab avec une touche enfoncée : on relâche tout pour éviter que
            # le personnage continue d'avancer tout seul.
            self.held.clear()
            self.pressed.clear()
            self.released.clear()

    # -- requêtes -----------------------------------------------------------
    def is_held(self, keys: tuple[int, ...]) -> bool:
        return any(key in self.held for key in keys)

    def just_pressed(self, keys: tuple[int, ...]) -> bool:
        return any(key in self.pressed for key in keys)

    def just_released(self, keys: tuple[int, ...]) -> bool:
        return any(key in self.released for key in keys)

    def mouse_over(self, rect: pygame.Rect) -> bool:
        return rect.collidepoint(self.mouse_pos)

    # -- fin de frame -------------------------------------------------------
    def end_frame(self) -> None:
        self.pressed.clear()
        self.released.clear()
        self.mouse_pressed = False
        self.mouse_released = False
        self.pause_pressed = False
        self.restart_pressed = False
        self.fullscreen_pressed = False
        self.mute_pressed = False
