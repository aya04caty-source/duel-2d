"""Entités du jeu : joueur, balles, particules.

La physique du joueur est résolue axe par axe contre la grille de l'arène, ce
qui évite de traverser les murs et de rester coincé dans les coins.
"""

from __future__ import annotations

import math
import random

import pygame

from . import assets
from . import settings as S


def move_toward(value: float, target: float, delta: float) -> float:
    if value < target:
        return min(value + delta, target)
    return max(value - delta, target)


class Particle:
    __slots__ = ("pos", "vel", "color", "life", "max_life", "size", "gravity")

    def __init__(
        self,
        pos: pygame.Vector2,
        vel: pygame.Vector2,
        color: tuple[int, int, int],
        life: float = 0.5,
        size: int = 3,
        gravity: float = 900.0,
    ) -> None:
        self.pos = pygame.Vector2(pos)
        self.vel = pygame.Vector2(vel)
        self.color = color
        self.life = life
        self.max_life = life
        self.size = size
        self.gravity = gravity

    def update(self, dt: float) -> None:
        self.vel.y += self.gravity * dt
        self.vel.x *= 1.0 - min(1.0, 2.0 * dt)
        self.pos += self.vel * dt
        self.life -= dt

    @property
    def alive(self) -> bool:
        return self.life > 0

    def draw(self, surface: pygame.Surface) -> None:
        ratio = max(0.0, self.life / self.max_life)
        color = (
            int(self.color[0] * ratio),
            int(self.color[1] * ratio),
            int(self.color[2] * ratio),
        )
        radius = max(1, int(self.size * (0.4 + 0.6 * ratio)))
        pygame.draw.circle(surface, color, (int(self.pos.x), int(self.pos.y)), radius)


def burst(
    particles: list[Particle],
    pos: pygame.Vector2,
    color: tuple[int, int, int],
    count: int = 10,
    speed: float = 200.0,
    life: float = 0.5,
    size: int = 3,
) -> None:
    for _ in range(count):
        angle = random.uniform(0.0, math.tau)
        velocity = pygame.Vector2(math.cos(angle), math.sin(angle))
        velocity *= random.uniform(speed * 0.3, speed)
        particles.append(
            Particle(pos, velocity, color, life * random.uniform(0.6, 1.2), size)
        )


class Bullet:
    def __init__(
        self,
        pos: pygame.Vector2,
        vel: pygame.Vector2,
        owner: int,
        color: tuple[int, int, int],
    ) -> None:
        self.pos = pygame.Vector2(pos)
        self.vel = pygame.Vector2(vel)
        self.owner = owner
        self.color = color
        self.alive = True
        self.life = S.BULLET_LIFE

    @property
    def rect(self) -> pygame.Rect:
        radius = S.BULLET_RADIUS
        return pygame.Rect(
            int(self.pos.x) - radius,
            int(self.pos.y) - radius,
            radius * 2,
            radius * 2,
        )

    def update(self, dt: float, arena) -> None:
        self.life -= dt
        if self.life <= 0:
            self.alive = False
            return
        self.pos += self.vel * dt
        if (
            self.pos.x < 0
            or self.pos.x > S.WIDTH
            or self.pos.y < S.HUD_H
            or self.pos.y > S.HEIGHT
        ):
            self.alive = False
            return
        if arena.collides_solid(self.rect):
            self.alive = False

    def draw(self, surface: pygame.Surface) -> None:
        assets.draw_bullet(surface, self.pos, self.color, S.BULLET_RADIUS)


class Player:
    def __init__(
        self,
        index: int,
        spawn: pygame.Vector2,
        keys: dict[str, tuple[int, ...]],
        color: tuple[int, int, int],
        dark_color: tuple[int, int, int],
        name: str,
    ) -> None:
        self.index = index
        self.spawn = pygame.Vector2(spawn)
        self.keys = keys
        self.color = color
        self.dark_color = dark_color
        self.name = name

        self.x = float(spawn.x)
        self.y = float(spawn.y)
        self.vx = 0.0
        self.vy = 0.0
        self.facing = 1 if index == 0 else -1
        self.aim = pygame.Vector2(self.facing, 0)

        self.hp = S.MAX_HP
        self.alive = True
        self.respawn_timer = 0.0
        self.invuln = 0.0
        self.cooldown = 0.0
        self.jump_buffer = 0.0
        self.coyote = 0.0
        self.on_ground = False
        self.died = False

    # -- état ---------------------------------------------------------------
    @property
    def rect(self) -> pygame.Rect:
        return pygame.Rect(int(self.x), int(self.y), S.PLAYER_W, S.PLAYER_H)

    @property
    def center(self) -> pygame.Vector2:
        return pygame.Vector2(self.x + S.PLAYER_W / 2, self.y + S.PLAYER_H / 2)

    def reset(self, pos: pygame.Vector2 | None = None) -> None:
        point = pygame.Vector2(pos if pos is not None else self.spawn)
        self.x, self.y = float(point.x), float(point.y)
        self.vx = self.vy = 0.0
        self.hp = S.MAX_HP
        self.alive = True
        self.respawn_timer = 0.0
        self.invuln = S.INVULN_TIME
        self.cooldown = 0.0
        self.jump_buffer = 0.0
        self.coyote = 0.0
        self.on_ground = False
        self.died = False

    # -- mise à jour --------------------------------------------------------
    def update(self, dt: float, arena, inputs, bullets: list[Bullet], sfx) -> None:
        self.invuln = max(0.0, self.invuln - dt)
        self.cooldown = max(0.0, self.cooldown - dt)
        self.jump_buffer = max(0.0, self.jump_buffer - dt)
        self.coyote = max(0.0, self.coyote - dt)

        if not self.alive:
            self.respawn_timer -= dt
            if self.respawn_timer <= 0.0:
                self.reset()
            return

        self._read_input(dt, inputs, bullets, sfx)

        self.vy = min(S.MAX_FALL, self.vy + S.GRAVITY * dt)
        self._move(dt, arena)

        if self.on_ground:
            self.coyote = S.COYOTE_TIME

        if self.y > S.HEIGHT + S.FALL_DEATH_MARGIN:
            self.die()

    def _read_input(self, dt: float, inputs, bullets: list[Bullet], sfx) -> None:
        keys = self.keys
        left = inputs.is_held(keys["left"])
        right = inputs.is_held(keys["right"])
        up = inputs.is_held(keys["up"])
        down = inputs.is_held(keys["down"])
        direction = int(right) - int(left)

        if direction != 0:
            self.facing = direction
            self.vx = move_toward(
                self.vx, direction * S.MOVE_SPEED, S.MOVE_ACCEL * dt
            )
        else:
            friction = S.GROUND_FRICTION if self.on_ground else S.AIR_FRICTION
            self.vx = move_toward(self.vx, 0.0, friction * dt)

        aim = pygame.Vector2(direction, int(down) - int(up))
        if aim.length_squared() == 0:
            aim = pygame.Vector2(self.facing, 0)
        self.aim = aim.normalize()
        if self.aim.x != 0:
            self.facing = 1 if self.aim.x > 0 else -1

        if inputs.just_pressed(keys["jump"]):
            self.jump_buffer = S.JUMP_BUFFER
        if self.jump_buffer > 0.0 and self.coyote > 0.0:
            self.vy = -S.JUMP_SPEED
            self.jump_buffer = 0.0
            self.coyote = 0.0
            self.on_ground = False
            sfx.play("jump")
        if self.vy < 0.0 and inputs.just_released(keys["jump"]):
            self.vy *= S.JUMP_CUT

        if inputs.is_held(keys["shoot"]) and self.cooldown <= 0.0:
            self.shoot(bullets, sfx)

    def shoot(self, bullets: list[Bullet], sfx) -> None:
        origin = self.center + self.aim * (S.PLAYER_W * S.SHOOT_MUZZLE)
        bullets.append(
            Bullet(origin, self.aim * S.BULLET_SPEED, self.index, self.color)
        )
        self.cooldown = S.SHOOT_COOLDOWN
        sfx.play("shoot")

    # -- collisions ---------------------------------------------------------
    def _move(self, dt: float, arena) -> None:
        self.x += self.vx * dt
        rect = self.rect
        for tile in arena.solid_rects_near(rect):
            if rect.colliderect(tile):
                if self.vx > 0:
                    rect.right = tile.left
                elif self.vx < 0:
                    rect.left = tile.right
                self.x = float(rect.x)
                self.vx = 0.0
        self.x = max(0.0, min(self.x, float(S.WIDTH - S.PLAYER_W)))

        previous_bottom = self.y + S.PLAYER_H
        self.y += self.vy * dt
        rect = self.rect
        self.on_ground = False

        for tile in arena.solid_rects_near(rect):
            if rect.colliderect(tile):
                if self.vy > 0:
                    rect.bottom = tile.top
                    self.on_ground = True
                elif self.vy < 0:
                    rect.top = tile.bottom
                self.y = float(rect.y)
                self.vy = 0.0

        if self.vy >= 0:
            rect = self.rect
            for tile in arena.oneway_rects_near(rect):
                if rect.colliderect(tile) and previous_bottom <= tile.top + S.ONEWAY_TOLERANCE:
                    rect.bottom = tile.top
                    self.y = float(rect.y)
                    self.vy = 0.0
                    self.on_ground = True

    # -- dégâts -------------------------------------------------------------
    def take_damage(
        self, amount: int = 1, source: pygame.Vector2 | None = None, sfx=None
    ) -> bool:
        if not self.alive or self.invuln > 0.0:
            return False

        self.hp -= amount
        self.invuln = S.INVULN_TIME
        if source is not None and source.length_squared() > 0:
            knockback = source.normalize() * S.HIT_KNOCKBACK
            self.vx += knockback.x * S.HIT_PUSH
            self.vy = min(self.vy, -S.HIT_LIFT)
        if sfx is not None:
            sfx.play("hit")

        if self.hp <= 0:
            self.die()
            return True
        return False

    def die(self) -> None:
        if not self.alive:
            return
        self.alive = False
        self.hp = 0
        self.vx = self.vy = 0.0
        self.respawn_timer = S.RESPAWN_TIME
        self.died = True

    # -- rendu --------------------------------------------------------------
    def draw(self, surface: pygame.Surface) -> None:
        assets.draw_player(surface, self)
