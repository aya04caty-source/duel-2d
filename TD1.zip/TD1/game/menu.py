"""Menus cliquables à la souris : accueil, pause et résultats."""

from __future__ import annotations

import json
import math

import pygame

from . import assets
from . import settings as S


def load_stats() -> dict:
    data = {"p1_wins": 0, "p2_wins": 0, "matches": 0}
    try:
        with open(S.project_path(S.SAVE_FILE), "r", encoding="utf-8") as handle:
            loaded = json.load(handle)
    except (OSError, ValueError):
        return data
    if isinstance(loaded, dict):
        for key in data:
            if isinstance(loaded.get(key), int):
                data[key] = loaded[key]
    return data


class Button:
    def __init__(
        self,
        label: str,
        action: str,
        center: tuple[int, int],
        size: tuple[int, int] = (280, 54),
    ) -> None:
        self.label = label
        self.action = action
        self.rect = pygame.Rect(0, 0, *size)
        self.rect.center = center

    def update(self, inputs) -> str | None:
        if inputs.mouse_pressed and inputs.mouse_over(self.rect):
            return self.action
        return None

    def draw(self, screen: pygame.Surface, inputs) -> None:
        hovered = inputs.mouse_over(self.rect)
        pygame.draw.rect(
            screen, S.BTN_HOVER if hovered else S.BTN_BG, self.rect, border_radius=12
        )
        pygame.draw.rect(screen, S.BTN_EDGE, self.rect, width=2, border_radius=12)
        if hovered:
            accent = pygame.Rect(
                self.rect.left + 10, self.rect.top + 12, 4, self.rect.height - 24
            )
            pygame.draw.rect(screen, S.ACCENT, accent, border_radius=2)
        assets.draw_text(
            screen, self.label, 22, self.rect.center, S.WHITE,
            anchor="center", bold=True
        )


class MainMenu:
    def __init__(self) -> None:
        self.background = assets.make_background((S.WIDTH, S.HEIGHT))
        self.time = 0.0
        self.stats = load_stats()
        center_x = S.WIDTH // 2
        self.buttons = [
            Button("Jouer", "play", (center_x, 420)),
            Button("Tutoriel", "tutorial", (center_x, 490)),
            Button("Quitter", "quit", (center_x, 560)),
        ]

    def refresh(self) -> None:
        self.stats = load_stats()

    def update(self, dt: float, inputs) -> str | None:
        self.time += dt
        for button in self.buttons:
            action = button.update(inputs)
            if action is not None:
                return action
        return None

    def draw(self, screen: pygame.Surface, inputs) -> None:
        screen.blit(self.background, (0, 0))
        self._draw_decor(screen)

        center_x = S.WIDTH // 2
        title_font = assets.get_font(94, True)
        width_left = title_font.size("DUEL")[0]
        gap = 22
        total = width_left + gap + title_font.size("2D")[0]
        start = center_x - total // 2
        assets.draw_text(
            screen, "DUEL", 94, (start, 175), S.WHITE,
            anchor="midleft", bold=True, shadow=True
        )
        assets.draw_text(
            screen, "2D", 94, (start + width_left + gap, 175), S.ACCENT,
            anchor="midleft", bold=True, shadow=True
        )
        assets.draw_text(
            screen, "ARÈNE LOCALE · 2 JOUEURS", 22, (center_x, 242),
            S.TEXT_DIM, anchor="center", bold=True
        )

        for button in self.buttons:
            button.draw(screen, inputs)

        stats = self.stats
        assets.draw_text(
            screen,
            f"J1 {stats['p1_wins']} — {stats['p2_wins']} J2   ·   "
            f"{stats['matches']} match(s) joué(s)",
            19,
            (center_x, 636),
            S.TEXT,
            anchor="center",
        )
        assets.draw_text(
            screen,
            "J1 : ZQSD + Espace + F      ·      J2 : Flèches + Maj droite + Ctrl droit",
            16,
            (center_x, 674),
            S.TEXT_DIM,
            anchor="center",
        )
        assets.draw_text(
            screen, "Souris pour les menus", 14, (center_x, 700),
            S.TEXT_DIM, anchor="center"
        )

    def _draw_decor(self, screen: pygame.Surface) -> None:
        pulse = math.sin(self.time * 2.0) * 10
        for color, center_x in ((S.P1_COLOR, 150), (S.P2_COLOR, S.WIDTH - 150)):
            layer = pygame.Surface((360, 360), pygame.SRCALPHA)
            pygame.draw.circle(layer, (*color, 22), (180, 180), int(130 + pulse))
            pygame.draw.circle(layer, (*color, 55), (180, 180), 70, 3)
            screen.blit(layer, (center_x - 180, 190 - 180))


class PauseMenu:
    def __init__(self) -> None:
        self.overlay = pygame.Surface((S.WIDTH, S.HEIGHT), pygame.SRCALPHA)
        self.overlay.fill((8, 10, 18, 232))
        center_x = S.WIDTH // 2
        self.buttons = [
            Button("Reprendre", "resume", (center_x, 360)),
            Button("Recommencer", "restart", (center_x, 430)),
            Button("Menu principal", "menu", (center_x, 500)),
        ]

    def update(self, inputs) -> str | None:
        for button in self.buttons:
            action = button.update(inputs)
            if action is not None:
                return action
        return None

    def draw(self, screen: pygame.Surface, inputs) -> None:
        screen.blit(self.overlay, (0, 0))
        assets.draw_text(
            screen, "PAUSE", 72, (S.WIDTH // 2, 250), S.WHITE,
            anchor="center", bold=True, shadow=True
        )
        for button in self.buttons:
            button.draw(screen, inputs)


class ResultsMenu:
    def __init__(self, match) -> None:
        self.match = match
        self.overlay = pygame.Surface((S.WIDTH, S.HEIGHT), pygame.SRCALPHA)
        self.overlay.fill((8, 10, 18, 225))
        center_x = S.WIDTH // 2
        self.buttons = [
            Button("Rejouer", "replay", (center_x, 470)),
            Button("Menu principal", "menu", (center_x, 540)),
        ]

    def update(self, inputs) -> str | None:
        for button in self.buttons:
            action = button.update(inputs)
            if action is not None:
                return action
        return None

    def draw(self, screen: pygame.Surface, inputs) -> None:
        screen.blit(self.overlay, (0, 0))
        center_x = S.WIDTH // 2

        if self.match.match_winner is None:
            title = "MATCH NUL"
            color = S.TEXT
        else:
            winner = self.match.players[self.match.match_winner]
            title = f"{winner.name.upper()} REMPORTE LE MATCH"
            color = winner.color

        assets.draw_text(
            screen, "FIN DU MATCH", 26, (center_x, 190),
            S.TEXT_DIM, anchor="center", bold=True
        )
        assets.draw_text(
            screen, title, 52, (center_x, 250), color,
            anchor="center", bold=True, shadow=True
        )
        assets.draw_text(
            screen,
            f"Manches : {self.match.round_wins[0]} — {self.match.round_wins[1]}",
            30,
            (center_x, 330),
            S.WHITE,
            anchor="center",
            bold=True,
        )

        for index, player in enumerate(self.match.players):
            label_x = center_x - 150 if index == 0 else center_x + 150
            assets.draw_text(
                screen, f"J{index + 1}", 16, (label_x, 382),
                player.color, anchor="center", bold=True
            )
            for slot in range(S.ROUNDS_TO_WIN_MATCH):
                if index == 0:
                    px = center_x - 110 + slot * 22
                else:
                    px = center_x + 110 - slot * 22
                won = slot < self.match.round_wins[index]
                color = player.color if won else (52, 60, 88)
                pygame.draw.circle(screen, color, (px, 382), 7)

        for button in self.buttons:
            button.draw(screen, inputs)
