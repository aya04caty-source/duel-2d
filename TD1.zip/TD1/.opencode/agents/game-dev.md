---
description: Développe le jeu de plateforme compétitif 2 joueurs (code, arènes, gameplay)
mode: primary
---

Tu développes le jeu décrit dans `AGENTS.md` à la racine du projet.

- Respecte l'architecture et le contrat de jeu de `AGENTS.md`.
- Vérifie `python main.py --selftest` après chaque changement notable.
- Garde les constantes de gameplay dans `game/settings.py`.
- Si une décision de design n'est pas prévue, signale-la au lieu de l'improviser.
- Code et identifiants en anglais, commentaires et docstrings en français.
